﻿using HarmonyLib;
using System;
using System.Collections;
using UnityEngine;
using System.Reflection;
using TMPro;
namespace Ukrainian_Language
{
    public class Ukrainian_Language : Mod
    {
        public static AssetBundle FontBundle;
		public static string BundlePath;
        public static Logger logger;
        public override void Ready()
        {
            BundlePath = this.Path + "/font.assetbundle";
            UnityEngine.Debug.Log("Ready!");
            var langs = SokLoc.Languages.ToList<SokLanguage>();
            langs.Add(new SokLanguage { LanguageName = "Ukrainian", UnitySystemLanguage = SystemLanguage.Ukrainian });
            SokLoc.Languages = langs.ToArray();

            var langNamesField = typeof(SokLoc).GetField("localLanguageNames", BindingFlags.NonPublic | BindingFlags.Static);
            Dictionary<string, string> langNames = (Dictionary<string, string>)langNamesField.GetValue(null);
            langNames.Add("Ukrainian", "Українська");
            langNamesField.SetValue(null, langNames);
            var harmony = new Harmony("Ukrainian_Language");
            harmony.PatchAll(typeof(Patches));
        }
    }
    internal class Patches
    {
        [HarmonyPatch(typeof(FontManager), "Awake")]
        [HarmonyPostfix]
        public static void Awake()
        {
            bool flag = Ukrainian_Language.BundlePath != null;
            if (flag)
                Ukrainian_Language.FontBundle = AssetBundle.LoadFromFile(Ukrainian_Language.BundlePath);
            else
                Ukrainian_Language.logger.Log(LogType.Error, "Cant find bundle");
            bool flag2 = Ukrainian_Language.FontBundle != null;
            if (flag2)
            {
                FontManager.instance.RegularFontAsset = Ukrainian_Language.FontBundle.LoadAsset<TMP_FontAsset>("NotoSans-Bold SDF");
                FontManager.instance.TitleFontAsset = Ukrainian_Language.FontBundle.LoadAsset<TMP_FontAsset>("NotoSans-Bold SDF");
                FontManager.instance.WorldFontAsset = Ukrainian_Language.FontBundle.LoadAsset<TMP_FontAsset>("NotoSans-Bold SDF");
                Ukrainian_Language.logger.Log(LogType.Log, "Font loaded?");
            }
            else
                Ukrainian_Language.logger.Log(LogType.Error, "Cant find asset");
        }
    }
}