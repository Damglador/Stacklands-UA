# Українізатор Stacklands
Ukrainian translation for Stacklands. Thanks https://github.com/Kahdeg-15520487/StackLand_vietnamese_translation for the code.

Ось переклад, качайте, грайте, ніколи не використовуйте російську і радійте!

Дискорд для питань та пропозицій: Damglador#3663 (Не лініться звітувати про помилки)

# Встановлення
Thunderstore Launcher - тицніть кнопку "встановити" і готово

Manual, як мод - беріть папочку Risk_of_Rain_2_Ukrainian і кидайте її в Plugins за шляхом Steam\steamapps\common\Stacklands\BepInEx\plugins

# Скріншоти
<details>
<summary>Демонстрація перекладу</summary>

[![Меню](https://cdn.discordapp.com/attachments/745054179847962741/1087222572866883664/image.png)](https://cdn.discordapp.com/attachments/745054179847962741/1087222572866883664/image.png)
</details>

# Подяка за переклад
Номер: 5375411200135544 (Переказ як на картку)

<details>
<summary>QR:</summary> 

[![QR](https://i.imgur.com/by6E4OP.png)](https://i.imgur.com/by6E4OP.png)
</details>

## Список змін
<details>
<summary>0.5.1</summary>

* Персоналізований dll файл
</details>
<details>
<summary>0.5.0</summary>

* Дочасний реліз, звітуйте про помилки. Багато чого не перекладено
</details>